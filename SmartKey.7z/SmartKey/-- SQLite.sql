-- SQLite
INSERT INTO users ("id", "name", "last_name", "is_admin", "pin") VALUES ("01", "admin", "adminovic", true, "0000");
